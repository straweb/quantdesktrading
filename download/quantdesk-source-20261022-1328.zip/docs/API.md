# API Reference

Two surfaces:

1. **Next.js REST API** — `http://localhost:3000/api/*` (auth: HMAC session cookie `zterm_session` set by `POST /api/auth/login`; unauthorized calls return `401 {"error": "Unauthorized — login as admin"}`).
2. **Feed mini-service** — REST on `:3004` (server-side only) and **socket.io** on `:3003` (browser reaches it through Caddy: `io('/?XTransformPort=3003')`).

---

## 1. Next.js REST endpoints

### Auth

| Method & path | Body / query | Description |
|---|---|---|
| `POST /api/auth/login` | `{username, password}` | sets `zterm_session` cookie |
| `POST /api/auth/logout` | — | clears session |
| `GET /api/auth/me` | — | current user or `null` |

### Accounts & capital

| Method & path | Description |
|---|---|
| `GET /api/accounts` | all accounts + capital state (mode, base/pct, available cash, usable) |
| `POST /api/accounts` | create account (per-broker credential fields, encrypted at rest; live brokers: blank initial capital = 100 % of broker available cash) |
| `GET/PATCH/DELETE /api/accounts/[id]` | read / update (label, `isActive` routing, `credentials` (replace) or `credentialsMerge` (partial — blank keys kept), `capitalBase`, `capitalPct`, capital+mode) / delete |
| `GET /api/funds` | aggregated per-account funds ledgers |
| `POST /api/funds` | `{accountId?}` — pull REAL broker funds now (one account or every active live account; also runs automatically every 45 s) |
| `GET /api/portfolio` | live holdings + live marks + open positions |
| `GET /api/margin` | per-account broker margin vs usable (sandbox estimate fallback) |

### Broker sessions & diagnostics

Session flows (per broker, every attempt logged to console + `broker_logs`):
- **ICICI Breeze** — open the apiuser login URL → redirect `?apisession=` → paste it; the terminal exchanges it at `customerdetails` exactly like the Breeze SDK (GET with a JSON body `{SessionToken, AppKey}` — raw `node:https`, since Node fetch cannot send a GET body).
- **Dhan** — three flows: ① paste `PIN:TOTP` → `auth.dhan.co/app/generateAccessToken?dhanClientId=&pin=&totp=` returns the accessToken directly; ② partner consent (`partner/generate-consent` → `consent-login?consentId=` → paste the redirect `tokenId` → `partner/consume-consent`); ③ paste a direct JWT from web.dhan.co.
- **Shoonya** — official OAuth `https://api.shoonya.com/OAuthlogin/authorize/oauth?client_id={client_id}` → redirect `?code=` → paste; GenAcsTok checksum families are tried in order (`{code, checksum}` on NorenWClientAPI, full jData verifiers on NorenWClientTP) and every attempt is logged. QuickAuth alternative: paste `pwd:factor2(:totp)`.

| Method & path | Description |
|---|---|
| `GET /api/broker-auth` | auth status + flow descriptor + login URL + masked `credFields` (samples + stored values) for the Edit dialog |
| `POST /api/broker-auth` | `{accountId, action:'consent'\|'complete', code?}` — consent / session creation (flows above) |
| `POST /api/broker-test` | `{accountId}` — 4-step connectivity test: credentials → adapter mode → funds ₹ → quote LTP (timed, each underlying call logged) |
| `GET /api/broker-logs` | per-account raw call logs (every outbound broker call is tagged `[BROKER][tag]` and mirrored here) |
| `GET /api/feed/status` | live broker feed engine status: active source, ticking state, last tick age, last error, recent log lines |
| `GET /api/broker-orderbook` | live order book for one account |
| `GET /api/admin/audit` | order audit trail |

### Orders

| Method & path | Body | Description |
|---|---|---|
| `GET /api/orders` | — | aggregated master + leg orders |
| `POST /api/orders` | `{symbol, exchange, side, orderType, productType, lots?, qty?, price?, triggerPrice?, capitalPct?, absoluteAmount? ("abs:<₹>" tag), source?}` | place master order → fan-out to enabled accounts (capital-sized) |
| `POST /api/orders/cancel` | `{accountId, orderId}` | cancel one leg |
| `POST /api/orders/cancel-all` | `{symbols?}` | cancel all open orders (optionally filtered) |
| `POST /api/orders/squareoff` | `{symbols?}` | market-close open positions (optionally filtered) |
| `GET /api/positions` · `GET /api/trades` | — | aggregated positions / executed trades |

### Market data proxies (→ feed :3004)

| Method & path | Query | Description |
|---|---|---|
| `GET /api/market/candles` | `symbol, tf, bars` | OHLCV series |
| `GET /api/market/quote` | `symbols` (csv) | LTP/OHLC/bid/ask/volume + lotSize + instrumentType |
| `GET /api/market/ltp` | `symbols` | light LTP batch |
| `GET /api/market/status` | — | feed health mirror |
| `GET /api/market/index` | `symbols` | index constituents + contribution pts |
| `GET /api/market/fno` | — | F&O universe grouped by exchange (expiry, contracts, lot, spot) |

### Options desk

| Method & path | Query / body | Description |
|---|---|---|
| `GET /api/options/underlyings` | — | F&O underlyings + expiries |
| `GET /api/options/chain` | `underlying, expiry?, strikes?` | chain quotes + `ceAtm/peAtm` (CE floor / PE ceil), step, lot |
| `POST /api/options/ensure-strike` | `{underlying, strike, expiry?}` | create contracts on demand (master + mappings + feed universe) |

### Symbols

| Method & path | Description |
|---|---|
| `GET /api/symbols` | browse master symbols (`?symbols=a,b` for explicit list, `?q=` search, exchange/type filters) |
| `POST /api/symbols/sync` | master-contracts sync (indices/eq/futs/weekly-monthly options/BFO/MCX/CDS) → republishes feed universe |
| `GET /api/symbols/resolve` | broker-specific token mapping for a symbol |

### Automation

| Method & path | Description |
|---|---|
| `GET/POST /api/autorules` · `PATCH/DELETE /api/autorules/[id]` | auto-bot rules (TIME / INDEX / INDEX_RANGE / COMPOUND conditions, actions BUY/SELL/DEPLOY/CANCEL, strikes list, entry/SL/TGT legs, repeatDaily) |
| `GET/POST /api/gtt` · `PATCH/DELETE /api/gtt/[id]` | GTT orders (edge-trigger on LTP, arm/disarm, repeatDaily) |
| `GET/PATCH /api/copytrade` | copy-trade master/slave routing matrix |
| `GET/POST /api/tickrecorder` | tick recorder config + recorded sessions (POST: toggle / symbols) |
| `GET/POST /api/replay` | paper-trading replay (POST: `{action:'start'\|'stop', file?, random?, fromTs?, toTs?, speed 0.5–20}`) |
| `GET /api/stats/session` | session win rate, realized/unrealized/net ₹, pts, charges, per-account breakdown |
| `GET /api/feed` · `POST /api/feed` | active feed source list (includes disconnected accounts) / set source |

### Strategies

| Method & path | Description |
|---|---|
| `GET/POST /api/strategies` · `GET/PATCH/DELETE /api/strategies/[id]` | strategy CRUD |
| `GET /api/strategies/[id]/python` | exported Python code |
| `POST /api/strategy/run` | `{id?, code?, symbol, tf, bars, dryRun?}` — runs in a `python3` subprocess with the SDK; `signal()` routes orders (source `PYTHON`) |

---

## 2. Feed mini-service — REST (:3004)

| Path | Method | Description |
|---|---|---|
| `/health` | GET | `{ok, symbols, ts}` — watchdog target |
| `/candles` | GET | `?symbol&tf&bars` OHLCV (deterministic 3-session 1m backfill + aggregated TFs) |
| `/ltp` · `/quote` · `/depth` | GET | batch market data |
| `/feed-source` | GET/POST | active feed account (persisted to `db/feed-source.json`) |
| `/feed-status` | GET | live broker feed engine: source, connected, last tick age, last error, log ring |
| `/universe` | POST | publish symbol universe (from master sync) |

**Live broker feed engine** — when the active source is a live account, the feed service polls that broker's quote APIs every second (Dhan `marketfeed/quote` batched per segment, Shoonya `GetQuote`, Breeze `/quotes`), maps master symbols via `SymbolMapping`, decrypts the account session (re-read every 60 s), and pushes ticks into the same pipeline as the sim engine (fed symbols skip the random walk). Symbol mappings re-read every 2 min; status surfaces on `/feed-status`.
| `/tick-config` | GET/POST | tick recorder on/off + symbol list (`db/ticks/tick-recorder.json`) |
| `/tick-sessions` | GET | recorded session DBs |
| `/tick-sample` | GET | sample rows from a session (replay preview) |
| `/replay-config` | POST | `start/stop` replay `{file?, random?, fromTs?, toTs?, speed}` |
| `/replay-status` | GET | replay progress |

## 3. Socket.io channels (:3003)

**Emits (client → server)**

| Event | Payload | Purpose |
|---|---|---|
| `subscribe` / `unsubscribe` | `string[]` symbols | tick stream control |
| `sync:sub` | `{underlyings, indices, …}` | register per-socket sync parameters |

**Events (server → client)**

| Event | Rate | Payload |
|---|---|---|
| `ticks` | ~250 ms | `Record<symbol, Tick>` (ltp/ohlc/bid/ask/vol) |
| `sync:core` | 1 s | accounts (incl. capital base/pct/cash), positions, orders, trades, funds, session stats |
| `sync:chain` | 1 s | option chain meta per underlying (CE floor / PE ceil ATM, ±15 steps) |
| `sync:index` | 1 s | index constituents + points contribution |

Client helpers live in `src/components/terminal/lib/socket.ts` (ticks) and `src/components/terminal/lib/sync.ts` (`onSync` / `useSyncChannel` / `useSyncData`, with REST fallback).
